(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_b9c8d86b._.js",
  "static/chunks/ed41d_next_dist_compiled_react-dom_c1c983ca._.js",
  "static/chunks/ed41d_next_dist_compiled_react-server-dom-turbopack_55f56912._.js",
  "static/chunks/ed41d_next_dist_compiled_next-devtools_index_7c814368.js",
  "static/chunks/ed41d_next_dist_compiled_ea85b96c._.js",
  "static/chunks/ed41d_next_dist_client_f558ee28._.js",
  "static/chunks/ed41d_next_dist_b61fa2c4._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
