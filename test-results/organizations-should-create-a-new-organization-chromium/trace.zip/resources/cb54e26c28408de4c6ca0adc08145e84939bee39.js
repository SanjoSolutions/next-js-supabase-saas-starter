(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__4881513b._.css",
  "static/chunks/d491c_next-themes_dist_index_mjs_f42fd2e4._.js"
],
    source: "dynamic"
});
