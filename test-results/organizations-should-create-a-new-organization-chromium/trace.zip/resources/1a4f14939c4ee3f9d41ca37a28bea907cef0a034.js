(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/64bb2_@supabase_auth-js_dist_module_09a93de1._.js",
  "static/chunks/a94f9_tailwind-merge_dist_bundle-mjs_mjs_f110c13e._.js",
  "static/chunks/node_modules__pnpm_51b1de31._.js",
  "static/chunks/_d806dd8b._.js"
],
    source: "dynamic"
});
